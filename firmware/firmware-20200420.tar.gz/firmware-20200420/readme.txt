20200420固件说明:


刷机方法:
sf probe 0
sf lock 0
fatload mmc 0 0x82000000 u-boot.20200419.bin
sf erase 0x0 0x80000
sf write 0x82000000 0x0 $(filesize)


reset重启后,自动升级,然后启动


注意:
u-boot,kernel,rootfs这三个文件,是自动升级使用的,不要直接刷到分区.
如果需要自己刷到分区,请用这三个:


u-boot.20200419.bin
openwrt-hi35xx-18ev200-default-uImage
openwrt-hi35xx-18ev200-default-root.squashfs



更新功能:
1.修改/etc/config/wireless文件
将Openwrt/1234567890修改成自己的路由器ssid和密码
或者自己创建一个Openwrt/1234567890的热点
然后执行wifi生效.
